IN this folder you will find some scripts so you can try out the queries in the book for yourself.

GoldClub.mdb is a complete Access database so you only need to download it and open it. All the tables and data are there.  

For the other platforms you will find a script.  This is a text file with the create commands to make the tables and then commands to insert the data.  

Consult your product's help to find out how to read commands from a script file.  It may also be possible to just cut and paste the contents of the file into an SQL command window.

The scripts are all very similar so if the one for you platform is not there you will more than likely find that one of the others will work just fine.

Enjoy.